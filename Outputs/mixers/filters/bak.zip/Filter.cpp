/* ########################################################################

   DACMixer - Class to allow Muse/2 to output a module to a Digital Stream.

   This file contains the filters and echos

   ########################################################################
*/
extern "C" {
int somPrintf (char *fmt, ...);
}

// High C requires
#pragma off(behaved)

#include "Filter.h"

#ifdef CPPCOMPILE
#define _min(A,B) ((A) < (B)?(A):(B))
#define _max(A,B) ((A) > (B)?(A):(B))
#endif

class LightFilter : public Filter
{
   long FilterLeft;
   long FilterRight;

   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
   void DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In);

   LightFilter() : FilterLeft(0), FilterRight(0) {};
};

class Light2Filter : public Filter
{
   long FilterLeft;
   long FilterRight;

   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
   void DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In);

   Light2Filter() : FilterLeft(0), FilterRight(0) {};
};

class HeavyDeepFilter : public Filter
{
   long FilterLeft;
   long FilterRight;
   long PFilterLeft;
   long PFilterRight;

   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
   void DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In);

   HeavyDeepFilter() : FilterLeft(0), FilterRight(0), PFilterLeft(0), PFilterRight(0) {};
};

class HeavyDeep2Filter : public Filter
{
   long FilterLeft;
   long FilterRight;
   long PFilterLeft;
   long PFilterRight;

   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
   void DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In);

   HeavyDeep2Filter() : FilterLeft(0), FilterRight(0), PFilterLeft(0), PFilterRight(0) {};
};

class HeavyDeep3Filter : public Filter
{
   long FilterLeft;
   long FilterRight;
   long PFilterLeft;
   long PFilterRight;
   long P2FilterLeft;
   long P2FilterRight;

   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
   void DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In);

   HeavyDeep3Filter() : FilterLeft(0), FilterRight(0), PFilterLeft(0), PFilterRight(0), P2FilterLeft(0), P2FilterRight(0) {};
};

class NoisyClipFilter : public Filter
{
   public:
   void DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In);
   void DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In);
};

Filter *Filter::Filters[FilterCount] = {new NoisyClipFilter,new Filter,
           new LightFilter,new Light2Filter,
           new HeavyDeepFilter,new HeavyDeep2Filter,new HeavyDeep3Filter};

#include <math.h>

/* ########################################################################

   This is the normal transformation, simply divides by ScalingConstant and
   clips.

   ########################################################################
*/
Filter::~Filter()
{
}

void Filter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
/*   #pragma loop_factor(64,50);
   float F = 0.99;
   float Q = ((float)ScalingConstant);// *(pow(65536.0*64*3,F)/(float)(65536.0*64*3));

   for (;Out < OutEnd; In++, Out++)
   {
      signed long W;
      if ((*In) > 0)
         W = pow((*In),F);
      else
         W = -1*pow(-1*(*In),F);

      *Out = _min(_max(W/ScalingConstant,-1*0x7FFF),0x7FFF);
   }

   #pragma loop_factor(64,-50);*/

   #pragma loop_factor(64,50);
   for (;Out < OutEnd; In++, Out++)
     *Out = _min(_max((*In)/ScalingConstant,-1*0x7FFF),0x7FFF);
   #pragma loop_factor(64,-50);
}

void Filter::DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   DoFilter16(Out,OutEnd,In);
}

void Filter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(64,50);

   for (;Out < OutEnd; In++, Out++)
     *Out = _min(_max((*In)/ScalingConstant,-1*0x7F),0x7F) + 0x80;

   #pragma loop_factor(64,-50);
}

void Filter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   DoFilter8(Out,OutEnd,In);
}

/* ########################################################################

   This is the light filter transform
      Works by averaging this byte with the last byte.

   ########################################################################
*/
void LightFilter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   signed long Sc = ScalingConstant*2;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In);
      NewRight = (In[1]);

      *Out = _min(_max((NewLeft + FilterLeft)/Sc,-1*0x7FFF),0x7FFF);
      Out[1] = _min(_max((NewRight + FilterRight)/Sc,-1*0x7FFF),0x7FFF);
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void LightFilter::DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long Sc = ScalingConstant*2;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In);

      *Out = _min(_max((NewLeft + FilterLeft)/Sc,-1*0x7FFF),0x7FFF);
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

void LightFilter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   signed long Sc = ScalingConstant*2;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In);
      NewRight = (In[1]);

      *Out = _min(_max((NewLeft + FilterLeft)/Sc,-1*0x7F),0x7F) + 0x80;
      Out[1] = _min(_max((NewRight + FilterRight)/Sc,-1*0x7F),0x7F) + 0x80;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void LightFilter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long Sc = ScalingConstant*2;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In);

      *Out = _min(_max((NewLeft + FilterLeft)/Sc,-1*0x7F),0x7F) + 0x80;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

/* ########################################################################

   This is the heavy filter transform

     4/4 N - 1/4 N + 1/4 L
      1/4 average of the last byte and the current byte.

   ########################################################################
*/
void Light2Filter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max(NewLeft - (NewLeft - FilterLeft)/4,-1*0x7FFF),0x7FFF);
      Out[1] = _min(_max(NewRight - (NewRight - FilterRight)/4,-1*0x7FFF),0x7FFF);
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void Light2Filter::DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max(NewLeft - (NewLeft - FilterLeft)/4,-1*0x7FFF),0x7FFF);
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

void Light2Filter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max(NewLeft - (NewLeft - FilterLeft)/4,-1*0x7F),0x7F) + 0x80;
      Out[1] = _min(_max(NewRight - (NewRight - FilterRight)/4,-1*0x7F),0x7F) + 0x80;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void Light2Filter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max(NewLeft - (NewLeft - FilterLeft)/4,-1*0x7F),0x7F) + 0x80;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

/* ########################################################################

   This is the heavy deep filter transform

     2/4 N + 1/4 L + 1/4 L2
      1/4 average of the last byte and the current byte.

   ########################################################################
*/
void HeavyDeepFilter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(64,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max(NewLeft/2 + (PFilterLeft + FilterLeft)/4,-1*0x7FFF),0x7FFF);
      Out[1] = _min(_max(NewRight/2 + (PFilterRight + FilterRight)/4,-1*0x7FFF),0x7FFF);

      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(64,-50);
}

void HeavyDeepFilter::DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max(NewLeft/2 + (PFilterLeft + FilterLeft)/4,-1*0x7FFF),0x7FFF);

      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeepFilter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(64,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max(NewLeft/2 + (PFilterLeft + FilterLeft)/4,-1*0x7F),0x7F) + 0x80;
      Out[1] = _min(_max(NewRight/2 + (PFilterRight + FilterRight)/4,-1*0x7F),0x7F) + 0x80;

      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(64,-50);
}

void HeavyDeepFilter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max(NewLeft/2 + (PFilterLeft + FilterLeft)/4,-1*0x7F),0x7F) + 0x80;

      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

/* ########################################################################

   This is the heavy deep filter transform

     2/4 N + 1/4 L + 1/4 L2
      1/4 average of the last byte and the current byte.

   ########################################################################
*/
void HeavyDeep2Filter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + FilterLeft)/3,-1*0x7FFF),0x7FFF);
      Out[1] = _min(_max((NewRight + PFilterRight + FilterRight)/3,-1*0x7FFF),0x7FFF);

      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep2Filter::DoFilter16m(unsigned short  *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + FilterLeft)/3,-1*0x7FFF),0x7FFF);

      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep2Filter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + FilterLeft)/3,-1*0x7F),0x7F) + 0x80;
      Out[1] = _min(_max((NewRight + PFilterRight + FilterRight)/3,-1*0x7F),0x7F) + 0x80;

      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep2Filter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + FilterLeft)/3,-1*0x7F),0x7F) + 0x80;

      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

/* ########################################################################

   This is the heavy deep 3 filter transform

     1/4 N + 1/4 N + 1/4 L
      1/4 average of the last byte and the current byte.

   ########################################################################
*/
void HeavyDeep3Filter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In+= 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + P2FilterLeft + FilterLeft)/4,-1*0x7FFF),0x7FFF);
      Out[1] = _min(_max((NewRight + PFilterRight + P2FilterRight + FilterRight)/4,-1*0x7FFF),0x7FFF);

      P2FilterLeft = PFilterLeft;
      P2FilterRight = PFilterRight;
      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep3Filter::DoFilter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + P2FilterLeft + FilterLeft)/4,-1*0x7FFF),0x7FFF);

      P2FilterLeft = PFilterLeft;
      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep3Filter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   signed long NewRight;
   for (;Out < OutEnd; In += 2, Out += 2)
   {
      NewLeft = (*In)/ScalingConstant;
      NewRight = (In[1])/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + P2FilterLeft + FilterLeft)/4,-1*0x7F),0x7F) + 0x80;
      Out[1] = _min(_max((NewRight + PFilterRight + P2FilterRight + FilterRight)/4,-1*0x7F),0x7F) + 0x80;

      P2FilterLeft = PFilterLeft;
      P2FilterRight = PFilterRight;
      PFilterLeft = FilterLeft;
      PFilterRight = FilterRight;
      FilterLeft = NewLeft;
      FilterRight = NewRight;
   }

   #pragma loop_factor(20,-50);
}

void HeavyDeep3Filter::DoFilter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(20,50);

   signed long NewLeft;
   for (;Out < OutEnd; In++, Out++)
   {
      NewLeft = (*In)/ScalingConstant;

      *Out = _min(_max((NewLeft + PFilterLeft + P2FilterLeft + FilterLeft)/4,-1*0x7F),0x7F) + 0x80;

      P2FilterLeft = PFilterLeft;
      PFilterLeft = FilterLeft;
      FilterLeft = NewLeft;
   }

   #pragma loop_factor(20,-50);
}

/* ########################################################################

   This is the same as the normal transformation, but it doesn't clip the
   output.

   ########################################################################
*/
void NoisyClipFilter::DoFilter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
   #pragma loop_factor(64,50);
   for (;Out < OutEnd; In++, Out++)
      *Out = (*In)/ScalingConstant;

   #pragma loop_factor(64,-50);
}

void NoisyClipFilter::DoFilter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
   #pragma loop_factor(64,50);

   for (;Out < OutEnd; In++, Out++)
     *Out = (*In)/ScalingConstant + 0x80;

   #pragma loop_factor(64,-50);
}
