/* ########################################################################

   The simple output filters

   ########################################################################
*/
#include <Muse.h>
#include <SimpFilt.hc>

#ifdef __WATCOMC__
#define SYSCALL _System
#else
#define SYSCALL
#endif

extern "C"
{
    void SYSCALL AsmFilter_8m       (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmClipFilter_8m   (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmLightFilter1_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter2_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter3_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmHeavyFilter1_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter2_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter3_8m (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2,unsigned long Last3);
    void SYSCALL AsmFilter_16m      (unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmClipFilter_16m  (unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmLightFilter1_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter2_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter3_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmHeavyFilter1_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter2_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter3_16m(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2,unsigned long Last3);
    void SYSCALL AsmFilter_8s       (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmClipFilter_8s   (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmLightFilter1_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter2_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter3_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmHeavyFilter1_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter2_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter3_8s (unsigned char *Out,unsigned char *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2,unsigned long Last3);
    void SYSCALL AsmFilter_16s      (unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmClipFilter_16s  (unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC);
    void SYSCALL AsmLightFilter1_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter2_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmLightFilter3_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1);
    void SYSCALL AsmHeavyFilter1_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter2_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2);
    void SYSCALL AsmHeavyFilter3_16s(unsigned short *Out,unsigned short *OutEnd,signed long *In,unsigned long SC,unsigned long Last1,unsigned long Last2,unsigned long Last3);
}

/*
   Clip/Scale Filter (default)
*/
void museScaleFilter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmFilter_16m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museScaleFilter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmFilter_16m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museScaleFilter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmFilter_8m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museScaleFilter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmFilter_8m ( Out, OutEnd, In, Owner->ScalingConstant );
}

/*
   Noisy Clip Filter
*/
void museNoisyClipFilter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmClipFilter_16m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museNoisyClipFilter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmClipFilter_16m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museNoisyClipFilter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmClipFilter_8m ( Out, OutEnd, In, Owner->ScalingConstant );
}

void museNoisyClipFilter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmClipFilter_8m ( Out, OutEnd, In, Owner->ScalingConstant );
}

/* ########################################################################

   This is the light filter transform
      Works by averaging this byte with the last byte.

   ######################################################################## */

void museLightFilter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter1_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter1_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLightFilter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter1_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museLightFilter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter1_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter1_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLightFilter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter1_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museLight2Filter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter2_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter2_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLight2Filter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter2_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museLight2Filter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter2_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter2_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLight2Filter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter2_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museLight3Filter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter3_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter3_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLight3Filter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmLightFilter3_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museLight3Filter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter3_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    AsmLightFilter3_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight );
    if ( OutEnd - Out >= 2 )
    {
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museLight3Filter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmLightFilter3_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft );
    if ( OutEnd - Out >= 1 )
    {
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

/* ########################################################################

   This is the heavy filter transform

   ########################################################################
*/
void museHeavyDeepFilter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter1_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    AsmHeavyFilter1_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight );
    if ( OutEnd - Out >= 4 )
    {
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeepFilter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter1_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    if ( OutEnd - Out >= 2 )
    {
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeepFilter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter1_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    AsmHeavyFilter1_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight );
    if ( OutEnd - Out >= 4 )
    {
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeepFilter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter1_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    if ( OutEnd - Out >= 2 )
    {
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep2Filter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter2_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    AsmHeavyFilter2_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight );
    if ( OutEnd - Out >= 4 )
    {
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep2Filter::Filter16m(unsigned short  *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter2_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    if ( OutEnd - Out >= 2 )
    {
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep2Filter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter2_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    AsmHeavyFilter2_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight );
    if ( OutEnd - Out >= 4 )
    {
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep2Filter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter2_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft );
    if ( OutEnd - Out >= 2 )
    {
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep3Filter::Filter16(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter3_16s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft, P2FilterLeft );
    AsmHeavyFilter3_16s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight, P2FilterRight );
    if ( OutEnd - Out >= 6 )
    {
        P2FilterLeft = In[(OutEnd-Out-6)];
        P2FilterRight = In[(OutEnd-Out-5)];
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep3Filter::Filter16m(unsigned short *Out,unsigned short *OutEnd,signed long *In)
{
    AsmHeavyFilter3_16m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft, P2FilterLeft );
    if ( OutEnd - Out >= 3 )
    {
        P2FilterLeft = In[(OutEnd-Out-3)];
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep3Filter::Filter8(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter3_8s ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft, P2FilterLeft );
    AsmHeavyFilter3_8s ( Out+1, OutEnd+1, In+1, Owner->ScalingConstant, FilterRight, PFilterRight, P2FilterRight );
    if ( OutEnd - Out >= 6 )
    {
        P2FilterLeft = In[(OutEnd-Out-6)];
        P2FilterRight = In[(OutEnd-Out-5)];
        PFilterLeft = In[(OutEnd-Out-4)];
        PFilterRight = In[(OutEnd-Out-3)];
        FilterLeft = In[(OutEnd-Out-2)];
        FilterRight = In[(OutEnd-Out-1)];
    }
}

void museHeavyDeep3Filter::Filter8m(unsigned char *Out,unsigned char *OutEnd,signed long *In)
{
    AsmHeavyFilter3_8m ( Out, OutEnd, In, Owner->ScalingConstant, FilterLeft, PFilterLeft, P2FilterLeft );
    if ( OutEnd - Out >= 3 )
    {
        P2FilterLeft = In[(OutEnd-Out-3)];
        PFilterLeft = In[(OutEnd-Out-2)];
        FilterLeft = In[(OutEnd-Out-1)];
    }
}

#ifdef CPPCOMPILE
#include <HandLst.hc>
museScaleFilterClass *museScaleFilter::__ClassObject = new museScaleFilterClass;
museScaleFilterClass::museScaleFilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museNoisyClipFilterClass *museNoisyClipFilter::__ClassObject = new museNoisyClipFilterClass;
museNoisyClipFilterClass::museNoisyClipFilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museLightFilterClass *museLightFilter::__ClassObject = new museLightFilterClass;
museLightFilterClass::museLightFilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museLight2FilterClass *museLight2Filter::__ClassObject = new museLight2FilterClass;
museLight2FilterClass::museLight2FilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museLight3FilterClass *museLight3Filter::__ClassObject = new museLight3FilterClass;
museLight3FilterClass::museLight3FilterClass()
{
    MajorVersion = 1;
    MinorVersion = 0;

    museHandlerList::__ClassObject->AddOFilter(this);
}

museHeavyDeepFilterClass *museHeavyDeepFilter::__ClassObject = new museHeavyDeepFilterClass;
museHeavyDeepFilterClass::museHeavyDeepFilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museHeavyDeep2FilterClass *museHeavyDeep2Filter::__ClassObject = new museHeavyDeep2FilterClass;
museHeavyDeep2FilterClass::museHeavyDeep2FilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

museHeavyDeep3FilterClass *museHeavyDeep3Filter::__ClassObject = new museHeavyDeep3FilterClass;
museHeavyDeep3FilterClass::museHeavyDeep3FilterClass()
{
   MajorVersion = 1;
   MinorVersion = 0;

   museHandlerList::__ClassObject->AddOFilter(this);
}

#endif
